module PolymorphismAndInheritance {
}