/**
 * @author Shane Hagan
 * Project: Polymorphism and Interface Practice Assignment TEKJava
 */

package com.hagan.polymorphismandinheritance;

public class Monster {
	protected String attackMsg;
	
	public Monster() {
		
	}
	
	public Monster(String attackMsg) {
		this.attackMsg = attackMsg;
	}
	
	public String attack() {
		return "I don't know how to attack!";
	}

}
