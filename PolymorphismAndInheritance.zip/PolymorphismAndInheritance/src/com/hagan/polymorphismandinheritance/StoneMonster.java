package com.hagan.polymorphismandinheritance;

public class StoneMonster extends Monster {

	public StoneMonster(String attackMsg) {
		super(attackMsg);
	}
	
	@Override
	public String attack() {
		return "Attack with stones!";
	}

}
