package com.hagan.polymorphismandinheritance;

public class WaterMonster extends Monster {

	public WaterMonster(String attackMsg) {
		super(attackMsg);
	}
	
	@Override
	public String attack() {
		return "Attack with water!";
	}

}
