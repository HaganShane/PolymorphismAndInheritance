package com.hagan.polymorphismandinheritance;

public class FireMonster extends Monster {

	public FireMonster(String attackMsg) {
		super(attackMsg);
	}
	
	@Override
	public String attack() {
		return "Attack with fire!";
	}
	
}
