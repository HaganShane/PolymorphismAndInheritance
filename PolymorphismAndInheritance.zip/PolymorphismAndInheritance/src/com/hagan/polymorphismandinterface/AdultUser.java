package com.hagan.polymorphismandinterface;

public class AdultUser implements LibraryUser {
	protected int age;
	protected String bookType;
	
	@Override
	public void registerAccount() {
		System.out.println("--- Testing Adult with age " + getAge() + " and book type " + getBookType() + " ---");
		if (age >= 12) {
			System.out.println("You have successfully registered a Adults Account.");
		}
		else {
			System.out.println("Sorry, age must be greater than 12 to register as a kid.");
		}
		
	}
	@Override
	public void requestBook() {
		if (bookType == "Fiction") {
			System.out.println("Book Issued successfully, please return the book within 7 days.");
		}
		else {
			System.out.println("Oops, you are allowed to take only adult fiction books.");
		}
		
		System.out.println("");
		
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBookType() {
		return bookType;
	}
	public void setBookType(String bookType) {
		this.bookType = bookType;
	}
}
