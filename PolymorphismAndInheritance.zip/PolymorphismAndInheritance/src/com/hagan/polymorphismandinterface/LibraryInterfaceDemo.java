/**
 * @author Shane Hagan
 * Project: Polymorphism and Interface Practice Assignment TEKJava
 */

package com.hagan.polymorphismandinterface;

public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		KidUsers kidTest = new KidUsers();
		AdultUser adultTest = new AdultUser();
		
		kidTest.setAge(10);
		kidTest.setBookType("Kids");
		
		kidTest.registerAccount();
		kidTest.requestBook();
		
		kidTest.setAge(18);
		kidTest.setBookType("Fiction");
		
		kidTest.registerAccount();
		kidTest.requestBook();
		
		adultTest.setAge(5);
		adultTest.setBookType("Kids");
		
		adultTest.registerAccount();
		adultTest.requestBook();
		
		adultTest.setAge(23);
		adultTest.setBookType("Fiction");
		
		adultTest.registerAccount();
		adultTest.requestBook();

	}

}
