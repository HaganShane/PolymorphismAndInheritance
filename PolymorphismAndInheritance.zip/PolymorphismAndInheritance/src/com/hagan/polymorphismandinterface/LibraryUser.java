package com.hagan.polymorphismandinterface;

public interface LibraryUser {
	void registerAccount();
	void requestBook();
}
